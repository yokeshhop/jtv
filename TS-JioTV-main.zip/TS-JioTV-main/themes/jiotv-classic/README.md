<h1 align='center'>✯ JIOTV <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/8a/Jio_TV_logo.svg/1200px-Jio_TV_logo.svg.png" width="40" height="40"> CLASSIC ✯</h1>

<!-- DO NOT EDIT FILE AND ADD YOU NAME HERE AND PUBLISH -->
<!-- © 2021-22 TechieSneh -->

<h4 align='center'>📺 The PHP Script For Grab Streaming Links and Play it , This Works Only on Android & Android TV
Through LocalHost <br><br>🌟 Star This Repositry Befor Copying 😎<br>😠 Don't Remove Credits<br>Don't Edit This Script
😈<br><br>Login With Your Own Credentials In This Script</h4>
<br>

<h2>😇 Features :</h2>

- HQ Streaming Free of Cost <br>
- Will Works In 250, 400, 600, 800, 1200(FEW NOT SUPPORT) in this Given Qualities
- Web Play Supports
- Works on Mobile, AndroidTV or PC Browser Perfect

<br>
<h2>💖 NEW FEATURES :</h2>

- Search Feature Added<br>

1. 🔍 SEARCH BY CHANNEL NAME 
```
e.g.  Sony,Zee,Star ...
```
2. 🔍 SEARCH BY GENRE 
```
e.g.  Entertainment,Kids,Movies,Music ...
```
3. 🔍 SEARCH BY LANGUAGE 
```
e.g.  Hindi,Tamil,Kannada,Odia ...
```

<h2>📸 SCREENSHOTS : </h2>

<img src="https://raw.githubusercontent.com/mitthu786/TS-JioTV/main/screenshots/jiotv-classic/classic.png" width="400" height="200">

<br>

<img src="https://raw.githubusercontent.com/mitthu786/TS-JioTV/main/screenshots/main/play.png" width="400" height="200">

<br>
<h2>🤐 DOWNLOAD ZIP HERE :</h2>

```py
https://github.com/mitthu786/TS-JioTV/blob/main/themes/jiotv-classic/tsclassic.zip?raw=true
```

👉 OR 👈

[DOWNLOAD FROM HERE](https://github.com/mitthu786/TS-JioTV/blob/main/themes/jiotv-classic/tsclassic.zip?raw=true)

<h2>🚸 Warnings :</h2>

- This is Just For Educational Purpose
- DO NOT Sell this Script, This is 💯% Free

<h3>🤗 Meet Me : </h3>

• For any Support Join Our Group [Techie Sneh](https://telegram.me/techiesneh)
• OR Contact at [ProtonMail](mailto:techiesneh@protonmail.com)

<br>

---
<h4 align='center'>© 2021-22 Techie Sneh</h4>

<!-- DO NOT REMOVE THIS CREDIT -->

